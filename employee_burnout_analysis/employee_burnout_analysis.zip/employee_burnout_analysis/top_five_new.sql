SELECT * FROM employee_burnout.table 
ORDER BY `Burn rate` DESC 
LIMIT 5 

